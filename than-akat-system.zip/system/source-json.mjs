// Some upstream text fields contain literal C0 characters, which JSON forbids.
// Escape those characters inside strings only; preserve their values and reject
// every other syntax error. Never strip records, edit numbers, or use stale data.
export function parseSourceJson(input){
  const original=String(input).replace(/^\uFEFF/,'');
  let error;
  try{return {data:JSON.parse(original),text:original,repairedControls:0};}catch(e){error=e;}
  let inside=false,escaped=false,last=0,repairedControls=0;
  const parts=[];
  for(let i=0;i<original.length;i++){
    const ch=original[i];
    if(!inside){if(ch==='"')inside=true;continue;}
    if(escaped){escaped=false;continue;}
    if(ch==='\\'){escaped=true;continue;}
    if(ch==='"'){inside=false;continue;}
    if(ch.charCodeAt(0)<32){
      parts.push(original.slice(last,i),'\\u'+ch.charCodeAt(0).toString(16).padStart(4,'0'));
      last=i+1;repairedControls++;
    }
  }
  if(repairedControls){
    parts.push(original.slice(last));const text=parts.join('');
    try{return {data:JSON.parse(text),text,repairedControls};}catch(e){error=e;}
  }
  const position=/position (\d+)/.exec(error?.message??'');
  // Do not include any source text in logs: it may contain contact information.
  throw new SyntaxError('Downloaded source is not valid JSON'+(position?' at position '+position[1]:''));
}
