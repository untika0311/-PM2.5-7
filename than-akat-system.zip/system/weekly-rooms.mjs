import {qualifyingRooms,roomsReport} from './core.mjs';
const fields=['SnapshotRow','HealthZone','Province','District','Subdistrict','Type','EvaluationResult','SelfAssessment'];
const sourceUrl='https://app.anamai.moph.go.th/podfoon/api/cleanroom/roomlists';
function validDate(date){return /^\d{4}-\d{2}-\d{2}$/.test(date)&&new Date(date+'T12:00:00Z').toISOString().slice(0,10)===date;}
export function makeWeeklySnapshot(rows,asOf,fetchedAt=new Date().toISOString()){
  if(!validDate(asOf)||!Number.isFinite(Date.parse(fetchedAt)))throw Error('Invalid weekly snapshot date');
  const original=roomsReport(rows,asOf);
  if(original.duplicateRows)throw Error('Exact duplicate source records need review before weekly export');
  const selected=qualifyingRooms(rows,asOf).map((r,i)=>({SnapshotRow:i+1,HealthZone:r.HealthZone,Province:r.Province,District:r.District??'',Subdistrict:r.Subdistrict??'',Type:r.Type,EvaluationResult:r.EvaluationResult,SelfAssessment:r.SelfAssessment.slice(0,10)}));
  return {schemaVersion:1,sourceUrl,asOf,fetchedAt,refreshSchedule:'Friday evening; manual upload for Saturday onward',qualifyingAtUpdate:original.total.rooms,rows:selected};
}
export function weeklyRoomsReport(snapshot,date){
  const allowed=['schemaVersion','sourceUrl','asOf','fetchedAt','refreshSchedule','qualifyingAtUpdate','rows'];
  if(snapshot?.schemaVersion!==1||snapshot.sourceUrl!==sourceUrl||!validDate(snapshot.asOf)||!validDate(date)||snapshot.asOf>date||!Array.isArray(snapshot.rows)||Object.keys(snapshot).some(k=>!allowed.includes(k)))throw Error('Invalid or future weekly cleanroom snapshot');
  const ids=new Set();
  for(const row of snapshot.rows){
    if(Object.keys(row).length!==fields.length||Object.keys(row).some(k=>!fields.includes(k))||!Number.isInteger(row.SnapshotRow)||row.SnapshotRow<1||ids.has(row.SnapshotRow)||fields.slice(1).some(k=>typeof row[k]!=='string')||!validDate(row.SelfAssessment))throw Error('Invalid weekly room row; upload the prepared file without editing it');
    ids.add(row.SnapshotRow);
  }
  if(qualifyingRooms(snapshot.rows,snapshot.asOf).length!==snapshot.rows.length||snapshot.qualifyingAtUpdate!==snapshot.rows.length)throw Error('Weekly snapshot contains ineligible or missing rows');
  const report=roomsReport(snapshot.rows,date);
  return {...report,sourceMode:'weekly',sourceDate:snapshot.asOf,sourceFetchedAt:snapshot.fetchedAt,sourceAgeDays:Math.round((Date.parse(date)-Date.parse(snapshot.asOf))/864e5),method:report.method+'; คำนวณอายุใหม่ทุกวันจากทะเบียนที่อัปเดตรายสัปดาห์ ณ '+snapshot.asOf+'; รายการเพิ่ม/แก้ไขหลังวันดังกล่าวจะปรากฏเมื่ออัปเดตชุดข้อมูลถัดไป'};
}
