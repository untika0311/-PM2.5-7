param([string]$Date = ([DateTime]::Now.ToString('yyyy-MM-dd',[cultureinfo]::InvariantCulture)), [switch]$AirOnly)
$ErrorActionPreference = 'Stop'
$root = Split-Path $PSScriptRoot -Parent
$cache = Join-Path $root 'private-cache'
New-Item -ItemType Directory -Force -Path $cache | Out-Null
# Supply missing public intermediates while retaining normal trust and hostname checks.
# Sources: letsencrypt.org/certs/gen-y/int-yr1.pem and root-yr-by-x1.pem
$script:caArgs = @()
if (Test-Path -LiteralPath '/etc/ssl/certs/ca-certificates.crt') {
  $intermediates = @'
-----BEGIN CERTIFICATE-----
MIIE2zCCAsOgAwIBAgIRAKICU/FfJpHAXcHOE7m8yk4wDQYJKoZIhvcNAQELBQAw
LjELMAkGA1UEBhMCVVMxDTALBgNVBAoTBElTUkcxEDAOBgNVBAMTB1Jvb3QgWVIw
HhcNMjUwOTAzMDAwMDAwWhcNMjgwOTAyMjM1OTU5WjAzMQswCQYDVQQGEwJVUzEW
MBQGA1UEChMNTGV0J3MgRW5jcnlwdDEMMAoGA1UEAxMDWVIxMIIBIjANBgkqhkiG
9w0BAQEFAAOCAQ8AMIIBCgKCAQEAoVi8X2xCYgMXvJxNPKp/oF13UMgmPABB07VC
LNDtoXmt9luEZNJSBV10VyT1Pz6LD8Zq1d2gc43WNl1AdRrj4sEnazbOiz0nPpmG
Bp2hui49oZtDIY6wdKeZAi5BbNU20CH6RSBBMLSQ9cXrH8dxdv4PAJ45ssGML68U
SE3BsjC2a6cAN9L5CgXVIQi5tfNiTPoFZZ3S0OlXqLmmtdV95udWAb5b6e/F49Di
CsH0Y00Ag72BVIb1hzynmKe+X0mERBTtsb3BwmpV9ipeBjMLoR/D9cHxHQCWoi5l
TmXwY015J5rGelz1nZjJuxc2kioaX29XJBnhMkP531rSdG5uMwIDAQABo4HuMIHr
MA4GA1UdDwEB/wQEAwIBhjATBgNVHSUEDDAKBggrBgEFBQcDATASBgNVHRMBAf8E
CDAGAQH/AgEAMB0GA1UdDgQWBBQfLzW+RhSCzUCxrnksVXj699Ro+zAfBgNVHSME
GDAWgBTe51tg0CJtQCh9Pw0B/qS1UrRRlDAyBggrBgEFBQcBAQQmMCQwIgYIKwYB
BQUHMAKGFmh0dHA6Ly95ci5pLmxlbmNyLm9yZy8wEwYDVR0gBAwwCjAIBgZngQwB
AgEwJwYDVR0fBCAwHjAcoBqgGIYWaHR0cDovL3lyLmMubGVuY3Iub3JnLzANBgkq
hkiG9w0BAQsFAAOCAgEA0+zvMq3kHig1ddTmmm+RibTr9/RpX7k4buanMMRqbV/y
IvP82zAHN3mvaw+cASuVsdpd0ikjhr4hnhJQLQOzOp2ccKrsdGOAgo0vddeISFAq
EWEV4lmUM3vFF796up+bSgmJ1u6RupDCMxDgF8M3eLvGuj6L0lu3zkQ0KuQLnKxL
tB0oQqn1Idg5CuuGpMvQzk29Pa3D/qHurc0EIM9SxukQuJqq63lxsYyRQFU8yMBO
hq1w5LbfaWNRrz1uklOfI/pYkAb2E2MTZrAMQkBIE2S8Jt1F8gRc96o/xOsrgvSk
a84AisX6xq1lz1Z7jGvrnXc4TMcjxZTjiTaihcYI1JIXZiLtEMSCa5l3cu8YWd6z
dLRQlqRdclVjuQfNHawRJ6GWlkK0QJosivTKwdBw3KxEtzGo8yMHERbsy57gP1UX
HOMcmZYQC0gtyR3SxfenIM/MxC3Ia2Ypab/kQ/CTnlIn2KQ5JUC6NYrGCbhFN9bp
5lKJStEwCUnLpntcrXk5XVDCNv/5RyWpRThkGOV7GetKkQ0qAY8hCzWK6oqnAhDZ
cjlYVdWfqOw3DIOX6EDNBgAqHarRVxyF9QZdOaXSyPJ0ueD2BYJEBgaCGQ8rAaU/
Qc123V5LTXDZW4CcsPBDyhy4v+c8hClAyw/IkJlfBqxB9D+/wvIMHgECZ4ptP6o=
-----END CERTIFICATE-----

-----BEGIN CERTIFICATE-----
MIIF9DCCA9ygAwIBAgIRAPJLbRf52a18scn+p4eCaZ8wDQYJKoZIhvcNAQELBQAw
TzELMAkGA1UEBhMCVVMxKTAnBgNVBAoTIEludGVybmV0IFNlY3VyaXR5IFJlc2Vh
cmNoIEdyb3VwMRUwEwYDVQQDEwxJU1JHIFJvb3QgWDEwHhcNMjYwNTEzMDAwMDAw
WhcNMzIwOTAyMjM1OTU5WjAuMQswCQYDVQQGEwJVUzENMAsGA1UEChMESVNSRzEQ
MA4GA1UEAxMHUm9vdCBZUjCCAiIwDQYJKoZIhvcNAQEBBQADggIPADCCAgoCggIB
ANvGJnN78CTJdWL3+eGfsLN5TrNBJs+VH9hRXqRbwxu9sGNiB0BD1fcOxbSUQCJI
M1xE13Db+5Cw1w0s0EBYsvuIP/6joF0w8cuImbgR1OGgYbSQ4OpzI+DG8SGuTlcE
873OCS+kh3srlo6vl43M5OJg4Aeo1sfHp6kTJDoIiFBNJAY+OKfX/FUvYKuhjT+n
o49lmqmupSBI5PkBQiqrEGtWU5uxU/cQWHGu8jSjFBznZqvbNPLMXMLFxCb3WTfr
JBXXjqvWG+v4bjzxjjeAtOlU7qarRDvNOyAuQYLln904M+faKx8hnLCpJ15ZqaEg
cNlY+9MMWcC5yvL2A2j3l9+2buggZX+dOE91zYmIdawTvSZuVvlbRrAlLxIB6pwM
BjneXCjYQ8+3BCCjssbSNpZU3hTcBDdhfAlEDlYr6pEatnMdmDT5BqnKC92bd0Eh
M1fbLHioLccLCuievT8ZkPhZrq7Mii7gNXAcUEAR8+lzYal+9zTg7C5DALyVOeG/
CqfRAMn1KSHCR0NSA6P8tn/mGRlnCct5rtVCLnVySVpU6H1qGg3DgTOuskf8eahT
MiYbI5ezPJmO5ertalskQ1utp74+eDy92PI4ftHKTbq9IWhH4YZKh3WnJEIt+oQv
lYZbY8tpEroKrFB6PFGzrJIDRyts4HqvuH52RFj2zv/BAgMBAAGjgeswgegwDgYD
VR0PAQH/BAQDAgEGMBMGA1UdJQQMMAoGCCsGAQUFBwMBMA8GA1UdEwEB/wQFMAMB
Af8wHQYDVR0OBBYEFN7nW2DQIm1AKH0/DQH+pLVStFGUMB8GA1UdIwQYMBaAFHm0
WeZ7tuXkAXOACIjIGlj26ZtuMDIGCCsGAQUFBwEBBCYwJDAiBggrBgEFBQcwAoYW
aHR0cDovL3gxLmkubGVuY3Iub3JnLzATBgNVHSAEDDAKMAgGBmeBDAECATAnBgNV
HR8EIDAeMBygGqAYhhZodHRwOi8veDEuYy5sZW5jci5vcmcvMA0GCSqGSIb3DQEB
CwUAA4ICAQA8spSI95KKfn2W6GMmDpHBJSPaLbsS3W93cijJCRCYAc1fsJgL1FIL
7C0C9ecPOdcwB2fi0Dk2p94j9iTJCxmt5CFSKLRWwnXT2MMSXexVxqoVB79BdWPx
VXETkVme/qYSAuKVHh5Ps+5BixgmwS1JkjSAc+MfrUbNssVEEnH0aEiAh+rotXAV
JSP/Ye7LJPEwD9DWG72vVWbhAcuOf5OLjz57Ctk7MgQHynZ7+PlHJtajroCaIbtC
r6tcZZaAwUQm+jQyeWdV+2hv9deOYFmKeQyjjcSrN5Nadrw+L9DZJLbA1HqeNvLh
BgqpP0fvJq2N6EtD574N6eMI7uMsJTnji2UDz9el5XLSv9fqJMuDQtYVb2oTNoKp
oUqhxPVC0aq4eG5MESaIdn8b5ZGSSeAJLMHXljEdlNza+ncfkviXk1POLnnFdvx8
/gk6M374WbLWFXw8N141B/Rl/tINGfl1TxOIiqtiMYkL02RSGb1kq34BL9NPP27z
RGMuHGnzS3hFIrRTfKxrzUZ9RzQWzEG3K6fJ3r2nqSltkeytis9DIBoFY9VmVyjL
M71DMi+y1+TRSJVClEMwvA4yL++7q9XZx5r5wBRWB4kQTKH5qyoZnDw7iiuh1lID
yDFx8r7i9vIJU5HS3moZLkYWAOilMaV9N56A9Bgb6dNcHkvg3NoaYA==
-----END CERTIFICATE-----
'@
  $combined = Join-Path $cache 'verified-ca-bundle.pem'
  [IO.File]::WriteAllText($combined, [IO.File]::ReadAllText('/etc/ssl/certs/ca-certificates.crt') + "`n" + $intermediates)
  $script:caArgs = @('--cacert', $combined)
}
function Download-Json([string[]]$Urls, [string]$Name) {
  $failures = @()
  $curlTool = Get-Command curl -CommandType Application -ErrorAction SilentlyContinue | Select-Object -First 1
  if (-not $curlTool) { $curlTool = Get-Command curl.exe -CommandType Application -ErrorAction SilentlyContinue | Select-Object -First 1 }
  foreach ($candidate in $Urls) {
    $sourceHost = ([uri]$candidate).Host
    Write-Output "Downloading $Name from $sourceHost ..."
    $timer = [Diagnostics.Stopwatch]::StartNew()
    $tempFile = Join-Path $cache ($Name + '.download')
    try {
      if ($curlTool) {
        $PSNativeCommandUseErrorActionPreference = $false
        # Retry transient connect/transfer failures; retain full TLS verification.
        # --retry-max-time bounds whether another retry may start, not an active transfer.
        $timeouts = if ($AirOnly) { @('--connect-timeout', '8', '--max-time', '25') } else { @('--retry', '2', '--retry-all-errors', '--retry-delay', '5', '--retry-max-time', '240', '--connect-timeout', '30', '--max-time', '120') }
        $detail = & $curlTool.Source @script:caArgs --ipv4 --http1.1 --fail --silent --show-error @timeouts --output $tempFile $candidate 2>&1
        if ($LASTEXITCODE -ne 0) { throw "curl exit $LASTEXITCODE : $detail" }
        $body = [IO.File]::ReadAllText($tempFile)
      } else {
        $response = if ($AirOnly) { Invoke-WebRequest -Uri $candidate -TimeoutSec 25 } else { Invoke-WebRequest -Uri $candidate -TimeoutSec 120 -MaximumRetryCount 2 -RetryIntervalSec 5 }
        $body = if ($response.Content -is [byte[]]) { [Text.Encoding]::UTF8.GetString($response.Content) } else { $response.Content }
      }
      $parsed = $body | ConvertFrom-Json
      if ($Name -eq 'latest.json' -and -not $parsed.stations.Count) { throw 'Latest response has no stations' }
      if ($Name -eq 'history.json' -and ($parsed.result -ne 'OK' -or -not @($parsed.stations | Where-Object { $_.data.Count -gt 0 }).Count)) { throw 'History response has no hourly data' }
      if ($Name -eq 'rooms.json') {
        if (-not ($parsed -is [array]) -or -not $parsed.Count) { throw 'Cleanroom response is not a room list' }
        foreach ($field in @('HealthZone','Province','District','Subdistrict','Type','EvaluationResult','SelfAssessment')) {
          if ($field -notin $parsed[0].PSObject.Properties.Name) { throw "Cleanroom response missing required field: $field" }
        }
      }
      [IO.File]::WriteAllText((Join-Path $cache $Name),$body)
      Write-Output ("OK: $Name in {0:N1}s" -f $timer.Elapsed.TotalSeconds)
      return
    } catch {
      $reason = $_.Exception.Message
      $failures += "$sourceHost : $reason"
      Write-Warning "Could not download $Name from $sourceHost : $reason"
    }
  }
  throw ("Source download failed: $Name. " + ($failures -join ' | '))
}
$latestUrls = @('https://air4thai.pcd.go.th/forweb/getAQI_JSON.php','https://air4thai.com/forweb/getAQI_JSON.php')
function Get-AirHistory {
  Download-Json $latestUrls 'latest.json'
  $latest = Get-Content -Raw (Join-Path $cache 'latest.json') | ConvertFrom-Json
  $stationIds = @($latest.stations | Where-Object { $_.areaTH -match 'ขอนแก่น|มหาสารคาม|ร้อยเอ็ด|กาฬสิน' } | ForEach-Object stationID) -join ','
  if (-not $stationIds) { throw 'Region 7 stations missing' }
  $start = [datetime]::ParseExact($Date,'yyyy-MM-dd',[cultureinfo]::InvariantCulture).AddDays(-8).ToString('yyyy-MM-dd',[cultureinfo]::InvariantCulture)
  Write-Output "Requested date range (Gregorian): $start to $Date"
  $query = "stationID=$stationIds&param=PM25&type=hr&sdate=$start&edate=$Date&stime=00&etime=23"
  Download-Json @("https://air4thai.pcd.go.th/forweb/getHistoryData.php?$query","https://air4thai.com/forweb/getHistoryData.php?$query") 'history.json'
}
if ($AirOnly) {
  # Leave time for rendering, publishing and LINE before 08:00 Bangkok.
  $retryUntil = [DateTimeOffset]::Parse("${Date}T07:47:00+07:00", [cultureinfo]::InvariantCulture)
  $bestCount = 0
  $best = @{}
  do {
    try {
      Get-AirHistory
      $coverageJson = & node (Join-Path $PSScriptRoot 'check-air-coverage.mjs') $cache $Date
      if ($LASTEXITCODE -ne 0) { throw 'Could not verify Air4Thai station coverage' }
      $coverage = $coverageJson | ConvertFrom-Json
      Write-Output "Air4Thai 07:00 Bangkok: $($coverage.availableStations)/$($coverage.totalStations) stations complete."
      if ($coverage.availableStations -gt 0 -and $coverage.availableStations -ge $bestCount) {
        $bestCount = $coverage.availableStations
        foreach ($file in @('latest.json', 'history.json')) {
          $best[$file] = [IO.File]::ReadAllText((Join-Path $cache $file))
        }
      }
      if ($coverage.availableStations -gt 0 -and $coverage.availableStations -eq $coverage.totalStations) { break }
    } catch {
      Write-Warning $_.Exception.Message
    }
    $remaining = ($retryUntil - [DateTimeOffset]::UtcNow).TotalSeconds
    if ($remaining -le 0) { break }
    Start-Sleep -Seconds ([Math]::Min(180, $remaining))
  } while ($true)
  if ($bestCount -eq 0) { throw 'No station has a complete 24-hour PM2.5 window ending at 07:00 Bangkok. Report was not published or sent.' }
  foreach ($file in $best.Keys) {
    [IO.File]::WriteAllText((Join-Path $cache $file), $best[$file])
  }
} else {
  Get-AirHistory
}
if (-not $AirOnly) {
  $roomStart = [datetime]::ParseExact($Date,'yyyy-MM-dd',[cultureinfo]::InvariantCulture).AddYears(-1).ToString('yyyy-MM-dd',[cultureinfo]::InvariantCulture)
  Download-Json @("https://app.anamai.moph.go.th/podfoon/api/cleanroom/roomlists?filter_start=$roomStart&filter_end=$Date") 'rooms.json'
} else {
  Write-Output 'Cleanrooms: using the weekly register in cleanrooms-weekly.json; no cleanroom API request.'
}
[IO.File]::WriteAllText((Join-Path $cache 'fetched.json'),(@{date=$Date;fetchedAt=[DateTimeOffset]::UtcNow.ToString('o')}|ConvertTo-Json))
if ($AirOnly) { Write-Output 'Air4Thai downloaded. The daily report will read the weekly cleanroom register.' }
else { Write-Output 'Downloaded Air4Thai and cleanroom sources. Raw records remain in private-cache.' }
