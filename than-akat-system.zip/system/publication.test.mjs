import test from 'node:test';
import assert from 'node:assert/strict';
import {emptyLedger,planPublication,recordPublication} from './publication.mjs';
const config={firstIssueDate:'2026-11-01'};
test('pre-launch previews do not consume the first publication number',()=>{
  const ledger=emptyLedger(),preview=planPublication('2026-10-30',ledger,config);
  assert.equal(preview.label,'1/2570');assert.equal(preview.preview,true);
  assert.deepEqual(recordPublication(preview,ledger),ledger);
  assert.equal(planPublication('2026-11-01',ledger,config).label,'1/2570');
});
test('same date keeps its number, skipped dates do not inflate the publication count',()=>{
  let ledger=emptyLedger();
  ledger=recordPublication(planPublication('2026-11-01',ledger,config),ledger);
  assert.equal(planPublication('2026-11-01',ledger,config).label,'1/2570');
  assert.equal(recordPublication(planPublication('2026-11-01',ledger,config),ledger).issues.length,1);
  const second=planPublication('2026-11-03',ledger,config);assert.equal(second.label,'2/2570');
  ledger=recordPublication(second,ledger);
  assert.throws(()=>planPublication('2026-11-02',ledger,config),/before an existing/);
  assert.equal(planPublication('2026-11-01',ledger,config).label,'1/2570');
});
test('Thai fiscal-year rollover starts a new issue series and conflicts are rejected',()=>{
  let ledger=emptyLedger();ledger=recordPublication(planPublication('2027-09-30',ledger,config),ledger);
  assert.equal(planPublication('2027-10-01',ledger,config).label,'1/2571');
  assert.throws(()=>recordPublication({date:'2027-09-30',number:2,year:2570,preview:false},ledger),/changed/);
  assert.throws(()=>recordPublication({date:'2027-09-29',number:1,year:2570,preview:false},ledger),/Conflicting/);
});
