import test from 'node:test';import assert from 'node:assert/strict';
import fs from 'node:fs';import os from 'node:os';import path from 'node:path';import {randomUUID} from 'node:crypto';
import {parseSourceJson} from './source-json.mjs';import {acquireReportLock} from './local-run-lock.mjs';
test('source control characters are escaped without changing field values or numbers',()=>{
  const raw='[{"Details":"บรรทัดแรก\nบรรทัดสอง\tท้าย\rจบ\u0000","Capacity":28,"EvaluationResult":"ผ่าน","SelfAssessment":"2026-10-30"}]';
  const out=parseSourceJson(raw);assert.equal(out.repairedControls,4);
  assert.equal(out.data[0].Details,'บรรทัดแรก\nบรรทัดสอง\tท้าย\rจบ\u0000');
  assert.equal(out.data[0].Capacity,28);assert.equal(out.data[0].EvaluationResult,'ผ่าน');assert.equal(out.data[0].SelfAssessment,'2026-10-30');
  assert.deepEqual(JSON.parse(out.text),out.data);
});
test('valid escaped strings and whitespace are unchanged; other corruption is rejected',()=>{
  const data={Details:'a"b\\c\ntext',Capacity:28};const raw='\uFEFF'+JSON.stringify(data,null,2);
  const out=parseSourceJson(raw);assert.equal(out.repairedControls,0);assert.deepEqual(out.data,data);
  for(const bad of ['{"Capacity":2\u00001}','[{"Details":"a\nb","Capacity":}]','<html>error</html>','[{"Details":"truncated'])assert.throws(()=>parseSourceJson(bad),/not valid JSON/);
});
test('a second launcher is blocked until the first releases its lock',()=>{
  const file=path.join(os.tmpdir(),'than-akat-'+randomUUID()+'.lock');
  const release=acquireReportLock(file);
  try{assert.throws(()=>acquireReportLock(file),e=>e.code==='REPORT_BUSY');}finally{release();}
  assert.equal(fs.existsSync(file),false);const again=acquireReportLock(file);again();assert.equal(fs.existsSync(file),false);
});
