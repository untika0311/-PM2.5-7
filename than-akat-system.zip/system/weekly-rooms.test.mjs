import test from 'node:test';import assert from 'node:assert/strict';
import {makeWeeklySnapshot,weeklyRoomsReport} from './weekly-rooms.mjs';
const r={HealthZone:'เขตสุขภาพที่ 7',Province:'ขอนแก่น',District:'เมือง',Subdistrict:'ในเมือง',Type:'สถานบริการสาธารณสุข',EvaluationResult:'ผ่าน',SelfAssessment:'2025-11-01',LocationName:'PRIVATE NAME',Phone:'PRIVATE PHONE',Email:'PRIVATE EMAIL',Latitude:16.4,Longitude:102.8};
test('weekly source strips contact/location detail while preserving separate rooms in the same locality',()=>{
  const snap=makeWeeklySnapshot([r,{...r,LocationName:'SECOND PRIVATE NAME'}],'2026-10-30','2026-10-30T07:00:00Z');
  const serialized=JSON.stringify(snap);for(const forbidden of ['PRIVATE','LocationName','Phone','Email','Latitude','Longitude'])assert.equal(serialized.includes(forbidden),false);
  assert.equal(weeklyRoomsReport(snap,'2026-10-30').total.rooms,2);assert.equal(weeklyRoomsReport(snap,'2026-10-30').duplicateRows,0);
});
test('one-year eligibility expires daily without downloading the weekly source again',()=>{
  const snap=makeWeeklySnapshot([r],'2026-10-30');
  assert.equal(weeklyRoomsReport(snap,'2026-11-01').total.rooms,1);
  const next=weeklyRoomsReport(snap,'2026-11-02');assert.equal(next.total.rooms,0);assert.equal(next.sourceDate,'2026-10-30');assert.equal(next.sourceAgeDays,3);
});
test('future snapshots, accidental private fields and exact duplicate source rows are rejected',()=>{
  const snap=makeWeeklySnapshot([r],'2026-10-30');
  assert.throws(()=>weeklyRoomsReport(snap,'2026-10-29'),/future/);
  const leaked=structuredClone(snap);leaked.rows[0].Phone='private';assert.throws(()=>weeklyRoomsReport(leaked,'2026-10-30'),/Invalid weekly room/);
  assert.throws(()=>makeWeeklySnapshot([r,{...r}],'2026-10-30'),/duplicate/);
});
test('a valid empty weekly snapshot means zero qualified rooms, not a schema failure',()=>{
  const snap=makeWeeklySnapshot([],'2026-10-30');assert.equal(weeklyRoomsReport(snap,'2026-10-31').total.rooms,0);
});
