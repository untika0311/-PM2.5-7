import {level} from './core.mjs';

export function reportSummary(report) {
  const {air,rooms}=report;
  const available=air.provinces.filter(p=>Number.isFinite(p.value));
  const worst=available.length?Math.max(...available.map(p=>level(p.value).index)):-1;
  const advice=[
    ['ทำกิจกรรมได้ตามปกติ ติดตามค่าฝุ่นในพื้นที่','ทำกิจกรรมได้ตามปกติและสังเกตอาการ'],
    ['ทำกิจกรรมได้ตามปกติ เช็กค่าฝุ่นก่อนออกจากบ้าน','เลี่ยงออกกำลังกายกลางแจ้งและสังเกตอาการ'],
    ['ติดตามค่าฝุ่นก่อนออกจากบ้าน','ลดกิจกรรมกลางแจ้ง หากต้องออกนอกอาคารควรสวมหน้ากากป้องกันฝุ่น'],
    ['ลดหรือจำกัดกิจกรรมกลางแจ้ง สวมหน้ากากป้องกันฝุ่น','ลดกิจกรรมกลางแจ้ง เตรียมยาประจำตัว และสวมหน้ากากป้องกันฝุ่น'],
    ['งดออกกำลังกายกลางแจ้ง สวมหน้ากากป้องกันฝุ่น','อยู่ในห้องปลอดฝุ่น และปฏิบัติตามคำแนะนำแพทย์']
  ][worst]??['ข้อมูลฝุ่นไม่ครบ โปรดตรวจสอบค่าฝุ่นในพื้นที่ก่อนออกจากบ้าน','ติดตามค่าฝุ่นในพื้นที่และสังเกตอาการ'];
  const value=v=>Number.isFinite(v)?Number(v).toFixed(1):'ไม่มีข้อมูล';
  const stamp=air.stamp?.match(/^(\d{4}-\d{2}-\d{2})[ T](\d{2}:\d{2})/);
  const sourceDateTH=stamp?new Intl.DateTimeFormat('th-TH',{day:'numeric',month:'short',year:'numeric',timeZone:'Asia/Bangkok'}).format(new Date(stamp[1]+'T12:00:00+07:00')):null;
  const lines=[
    `🌤️ ทันอากาศ | เขตสุขภาพที่ 7`,
    stamp?`🕒 ข้อมูลฝุ่น วันที่ ${sourceDateTH} เวลา ${stamp[2].replace(':','.')} น.`:'🕒 ข้อมูลฝุ่น: เวลาข้อมูลไม่ตรงกัน/ข้อมูลไม่ครบ',
    '',
    `🍃 PM2.5 เฉลี่ยเขตสุขภาพที่ 7 ${value(air.mean)}${Number.isFinite(air.mean)?' มคก./ลบ.ม. ('+level(air.mean).name+')':''}`,
    ...(air.availableStations!==undefined?[`📡 เฉลี่ยจาก ${air.availableStations}/${air.totalStations} สถานีที่มีข้อมูลครบ 24 ชั่วโมง`]:[]),
    ...air.provinces.map(p=>{
      if (Number.isFinite(p.value)) return `📍 ${p.name} ${value(p.value)} มคก./ลบ.ม. (${level(p.value).name})`;
      if (Number.isFinite(p.hourlyValue)) return `📍 ${p.name} ${value(p.hourlyValue)} มคก./ลบ.ม.`;
      return `📍 ${p.name} ไม่มีข้อมูล`;
    }),
    `🚦 เกินมาตรฐาน 37.5: ${air.above===null?'ไม่มีข้อมูล':air.above+'/'+(air.availableProvinces??4)+' จังหวัดที่มีข้อมูล'}`,
    ...(air.missingStations?.length?['⚪ ข้อมูลไม่ครบ 24 ชม. '+air.missingStations.map(s=>s.province+' ('+s.id+')').join(', ')]:[]),
    ...(air.provinces.some(p=>!Number.isFinite(p.value)&&Number.isFinite(p.hourlyValue))?['จังหวัดที่ข้อมูลไม่ครบ 24 ชม. ใช้ค่ารายชั่วโมง ณ 07.00 น. เมื่อมีข้อมูล']:[]),
    '',
    `🏡 ห้องปลอดฝุ่นอาคารสาธารณะ ${rooms.total.rooms} ห้อง`,
    `ครอบคลุม ${rooms.total.districts} อำเภอ ${rooms.total.subdistricts} ตำบล`,
    '',
    `👨‍👩‍👧 ประชาชน: ${advice[0]}`,
    `🩺 กลุ่มเสี่ยง: ${advice[1]}`
  ];
  const high=air.provinces.filter(p=>p.highDays>=2).map(p=>p.name);
  if(high.length)lines.push('⚠️ คัดกรองเข้าเกณฑ์เปิด PHEOC ระดับจังหวัด: '+high.join(', ')+' (ยังไม่ใช่การยืนยันเปิดจริง)');
  return lines.join('\n');
}
