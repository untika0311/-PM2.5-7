import {level,reportedValue} from './core.mjs';

export function reportSummary(report) {
  const {air,rooms}=report;
  const available=air.provinces.filter(p=>Number.isFinite(p.value));
  const worst=available.length?Math.max(...available.map(p=>level(p.value).index)):-1;
  const advice=[
    ['ทำกิจกรรมได้ตามปกติ ติดตามค่าฝุ่นในพื้นที่','ทำกิจกรรมได้ตามปกติและสังเกตอาการ'],
    ['ทำกิจกรรมได้ตามปกติ เช็กค่าฝุ่นก่อนออกจากบ้าน','เลี่ยงออกกำลังกายกลางแจ้งและสังเกตอาการ'],
    ['ติดตามค่าฝุ่นก่อนออกจากบ้าน','ลดกิจกรรมกลางแจ้ง หากต้องออกนอกอาคารควรสวมหน้ากากป้องกันฝุ่น'],
    ['ลดหรือจำกัดกิจกรรมกลางแจ้ง สวมหน้ากากป้องกันฝุ่น','ลดกิจกรรมกลางแจ้ง เตรียมยาประจำตัว และสวมหน้ากากป้องกันฝุ่น'],
    ['งดออกกำลังกายกลางแจ้ง สวมหน้ากากป้องกันฝุ่น','อยู่ในห้องปลอดฝุ่น และปฏิบัติตามคำแนะนำแพทย์']
  ][worst]??['ข้อมูลฝุ่นไม่ครบ โปรดตรวจสอบค่าฝุ่นในพื้นที่ก่อนออกจากบ้าน','ติดตามค่าฝุ่นในพื้นที่และสังเกตอาการ'];
  const value=v=>Number.isFinite(v)?Number(v).toFixed(1):'ไม่มีข้อมูล';
  const stamp=air.stamp?.match(/^(\d{4}-\d{2}-\d{2})[ T](\d{2}:\d{2})/);
  const sourceDateTH=stamp?new Intl.DateTimeFormat('th-TH',{day:'numeric',month:'short',year:'numeric',timeZone:'Asia/Bangkok'}).format(new Date(stamp[1]+'T12:00:00+07:00')):null;
  const lines=[
    `🌤️ ทันอากาศ | เขตสุขภาพที่ 7`,
    stamp?`🕒 ข้อมูลฝุ่น วันที่ ${sourceDateTH} เวลา ${stamp[2].replace(':','.')} น.`:'🕒 ข้อมูลฝุ่น: เวลาข้อมูลไม่ตรงกัน/ข้อมูลไม่ครบ',
    '',
    `🍃 PM2.5 เฉลี่ยเขตสุขภาพที่ 7 ${value(air.mean)}${Number.isFinite(air.mean)?' มคก./ลบ.ม. ('+level(air.mean).name+')':''}`,
    ...air.provinces.map(p=>{
      const reading=reportedValue(p);
      if (Number.isFinite(reading)) return `📍 ${p.name} ${value(reading)} มคก./ลบ.ม. (${level(reading).name})`;
      return `📍 ${p.name} ไม่มีข้อมูล`;
    }),
    `🚦 พบค่าเฉลี่ยเกินมาตรฐาน 37.5: ${air.above===null?'ไม่มีข้อมูล':air.above+'/4 จังหวัด'}`,
    '',
    `🏡 ห้องปลอดฝุ่นอาคารสาธารณะ ${rooms.total.rooms} ห้อง`,
    `ครอบคลุม ${rooms.total.districts} อำเภอ ${rooms.total.subdistricts} ตำบล`,
    '',
    `👨‍👩‍👧 ประชาชน: ${advice[0]}`,
    `🩺 กลุ่มเสี่ยง: ${advice[1]}`
  ];
  const high=air.provinces.filter(p=>p.highDays>=2).map(p=>p.name);
  if(high.length)lines.push('⚠️ ผลคัดกรองเข้าเกณฑ์พิจารณายกระดับจังหวัด (PHEOC): '+high.join(', '));
  return lines.join('\n');
}
