import {level} from './core.mjs';

export function reportSummary(report) {
  const {air,rooms,date}=report;
  const dateTH=new Intl.DateTimeFormat('th-TH',{day:'numeric',month:'long',year:'numeric',timeZone:'Asia/Bangkok'}).format(new Date(date+'T12:00:00+07:00'));
  const available=air.provinces.filter(p=>Number.isFinite(p.value));
  const worst=available.length?Math.max(...available.map(p=>level(p.value).index)):-1;
  const advice=[
    ['ทำกิจกรรมได้ตามปกติ ติดตามค่าฝุ่นในพื้นที่','ทำกิจกรรมได้ตามปกติและสังเกตอาการ'],
    ['ทำกิจกรรมได้ตามปกติ เช็กค่าฝุ่นก่อนออกจากบ้าน','เลี่ยงออกกำลังกายกลางแจ้งและสังเกตอาการ'],
    ['ติดตามค่าฝุ่นก่อนออกจากบ้าน','ลดกิจกรรมกลางแจ้ง หากต้องออกนอกอาคารควรสวมหน้ากากป้องกันฝุ่น'],
    ['ลดหรือจำกัดกิจกรรมกลางแจ้ง สวมหน้ากากป้องกันฝุ่น','ลดกิจกรรมกลางแจ้ง เตรียมยาประจำตัว และสวมหน้ากากป้องกันฝุ่น'],
    ['งดออกกำลังกายกลางแจ้ง สวมหน้ากากป้องกันฝุ่น','อยู่ในห้องปลอดฝุ่น และปฏิบัติตามคำแนะนำแพทย์']
  ][worst]??['ข้อมูลฝุ่นไม่ครบ โปรดตรวจสอบค่าฝุ่นในพื้นที่ก่อนออกจากบ้าน','ติดตามค่าฝุ่นในพื้นที่และสังเกตอาการ'];
  const value=v=>Number.isFinite(v)?Number(v).toFixed(1):'ไม่มีข้อมูล';
  const lines=[
    `ทันอากาศ เขตสุขภาพที่ 7 | ${dateTH}${report.publication?' | ฉบับที่ '+report.publication.label:''}`,
    `ข้อมูลฝุ่น ณ ${air.stamp??'เวลาข้อมูลไม่ตรงกัน/ข้อมูลไม่ครบ'}`,
    `PM2.5 เฉลี่ยเขต ${value(air.mean)}${Number.isFinite(air.mean)?' มคก./ลบ.ม. ('+level(air.mean).name+')':''}`,
    air.provinces.map(p=>p.name+' '+value(p.value)).join(' | '),
    `เกินมาตรฐาน 37.5: ${air.above===null?'ข้อมูลไม่ครบ':air.above+'/4 จังหวัด'}`,
    `ห้องปลอดฝุ่นอาคารสาธารณะ ประเมินตนเองผ่านภายใน 1 ปี: ${rooms.total.rooms} ห้อง ใน ${rooms.total.districts} อำเภอ ${rooms.total.subdistricts} ตำบล`,
    ...(rooms.sourceDate?[`ทะเบียนห้องปลอดฝุ่น ณ ${new Intl.DateTimeFormat('th-TH',{day:'numeric',month:'long',year:'numeric',timeZone:'Asia/Bangkok'}).format(new Date(rooms.sourceDate+'T12:00:00+07:00'))} (อัปเดตรายสัปดาห์)`]:[]),
    `ประชาชน: ${advice[0]}`,
    `กลุ่มเสี่ยง: ${advice[1]}`
  ];
  const high=air.provinces.filter(p=>p.highDays>=2).map(p=>p.name);
  if(high.length)lines.push('คัดกรองเข้าเกณฑ์เปิด PHEOC ระดับจังหวัด: '+high.join(', ')+' (ยังไม่ใช่การยืนยันเปิดจริง)');
  const missing=air.provinces.filter(p=>p.past.slice(0,2).some(x=>x.max===null)).map(p=>p.name);
  if(missing.length)lines.push('ข้อมูลย้อนหลังสำหรับคัดกรอง PHEOC ไม่ครบ: '+missing.join(', '));
  return lines.join('\n');
}
