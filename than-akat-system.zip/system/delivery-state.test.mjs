import test from 'node:test';import assert from 'node:assert/strict';
import fs from 'node:fs';import os from 'node:os';import path from 'node:path';
import {bangkokDate,deliveryDecision,writeDeliveryReceipt,readDeliveryReceipt} from './delivery-state.mjs';
test('automatic retries continue until an accepted receipt for the same Bangkok day',()=>{
 const base={date:'2026-11-02',firstIssueDate:'2026-11-01',event:'schedule'};
 assert.equal(deliveryDecision(base).send,true);
 assert.equal(deliveryDecision({...base,receipt:{date:'2026-11-01'}}).run,true);
 assert.equal(deliveryDecision({...base,receipt:{date:'2026-11-02'}}).run,false);
 assert.equal(deliveryDecision({...base,event:'push',receipt:{date:'2026-11-02'}}).run,false);
 assert.equal(deliveryDecision({...base,receipt:{date:'2026-11-02'},targets:['personal','workgroup']}).run,true);
 assert.equal(deliveryDecision({...base,receipt:{date:'2026-11-02',acceptedTargets:['personal','workgroup']},targets:['personal','workgroup']}).run,false);
 assert.equal(deliveryDecision({...base,date:'2026-10-31'}).send,false);
 assert.deepEqual(deliveryDecision({...base,event:'workflow_dispatch',sendLine:false}),{run:true,send:false,reason:'Manual run'});
 assert.equal(bangkokDate(new Date('2026-11-01T18:00:00Z')),'2026-11-02');
});
test('receipt persists without tokens, recipient details or raw medical data',()=>{
 const dir=fs.mkdtempSync(path.join(process.cwd(),'.receipt-test-'));const file=path.join(dir,'receipt.json');
 try{assert.equal(readDeliveryReceipt(file),null);writeDeliveryReceipt(file,'2026-11-02',new Date('2026-11-02T00:03:00Z'));
 assert.deepEqual(readDeliveryReceipt(file),{schemaVersion:1,date:'2026-11-02',acceptedAt:'2026-11-02T00:03:00.000Z',acceptedTargets:['personal']});
 }finally{if(fs.existsSync(file))fs.unlinkSync(file);if(fs.existsSync(file+'.tmp'))fs.unlinkSync(file+'.tmp');fs.rmdirSync(dir)}
});
