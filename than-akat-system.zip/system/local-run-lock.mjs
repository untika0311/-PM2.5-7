import fs from 'node:fs';
import {randomUUID} from 'node:crypto';
export function acquireReportLock(file){
  const token=randomUUID();
  for(let attempt=0;attempt<2;attempt++){
    try{
      const fd=fs.openSync(file,'wx');
      try{fs.writeFileSync(fd,JSON.stringify({pid:process.pid,token,startedAt:new Date().toISOString()}));}finally{fs.closeSync(fd);}
      return ()=>{
        try{if(JSON.parse(fs.readFileSync(file,'utf8')).token===token)fs.unlinkSync(file);}catch(e){if(e.code!=='ENOENT')throw e;}
      };
    }catch(e){
      if(e.code!=='EEXIST')throw e;
      let running=true;
      try{
        const {pid}=JSON.parse(fs.readFileSync(file,'utf8'));
        if(Number.isInteger(pid)&&pid>0){try{process.kill(pid,0);}catch(check){if(check.code==='ESRCH')running=false;}}
      }catch{}
      if(!running){try{fs.unlinkSync(file);}catch(remove){if(remove.code!=='ENOENT')throw remove;}continue;}
      const busy=new Error('A report is already running. Please wait for the other window to finish.');busy.code='REPORT_BUSY';throw busy;
    }
  }
  throw Error('Could not acquire the report lock');
}
