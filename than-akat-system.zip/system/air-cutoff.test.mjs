import test from 'node:test';import assert from 'node:assert/strict';
import {airReport,PROVINCES} from './core.mjs';
function fixtures(){
 const end=Date.parse('2026-11-02T07:00:00+07:00');
 const stamp=t=>new Date(t+7*36e5).toISOString().slice(0,19).replace('T',' ');
 const latest={stations:PROVINCES.map(p=>({stationID:p.station,areaTH:p.name,nameTH:p.name,AQILast:{date:'2026-11-02',time:'09:00:00',PM25:{value:999}}}))};
 const history={result:'OK',stations:PROVINCES.map((p,i)=>({stationID:p.station,data:[...Array.from({length:72},(_,h)=>({DATETIMEDATA:stamp(end-h*36e5),PM25:10*(i+1)})),{DATETIMEDATA:stamp(end+36e5),PM25:900},{DATETIMEDATA:stamp(end+2*36e5),PM25:999}]}))};
 return {latest,history};
}
test('delayed reports use exactly the 07:00 cutoff and match the today history column',()=>{
 const {latest,history}=fixtures();const report=airReport(latest,history,'2026-11-02');
 assert.equal(report.stamp,'2026-11-02 07:00:00');assert.equal(report.mean,25);
 report.provinces.forEach((p,i)=>{assert.equal(p.value,(i+1)*10);assert.equal(p.value,p.past[0].value);assert.equal(p.stations[0].time,report.stamp);assert.equal(p.stations[0].value,p.value);assert.equal(p.past[2].minHours,24)});
 latest.stations.forEach(s=>{s.AQILast.time='15:00:00';s.AQILast.PM25.value=5});
 assert.deepEqual(airReport(latest,history,'2026-11-02').provinces.map(p=>p.value),[10,20,30,40]);
});
test('missing 07:00 endpoint stays N/A even when 08:00 and current readings exist',()=>{
 const {latest,history}=fixtures();history.stations[0].data.shift();
 const report=airReport(latest,history,'2026-11-02');assert.equal(report.provinces[0].value,null);assert.equal(report.provinces[0].past[0].value,null);assert.equal(report.mean,null);assert.equal(report.stamp,'2026-11-02 07:00:00');
});
