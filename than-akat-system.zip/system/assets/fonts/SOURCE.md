RSU Font — Rangsit University

Downloaded from the university's official font distribution:
https://www2.rsu.ac.th/info/downloads-fonts
https://www2.rsu.ac.th/files/rsufont.zip

Included original, unmodified files:
- RSU_light.ttf
- RSU_Regular.ttf
- RSU_BOLD.ttf

The report embeds these fonts without installing them in Windows.
