import fs from 'node:fs';
import {bangkokDate,readDeliveryReceipt,deliveryDecision} from './delivery-state.mjs';
const config=JSON.parse(fs.readFileSync('system/report-config.json','utf8'));
const decision=deliveryDecision({date:bangkokDate(),event:process.env.GITHUB_EVENT_NAME,sendLine:process.env.SEND_LINE==='true',firstIssueDate:config.firstIssueDate,receipt:readDeliveryReceipt('public/line-delivery-state.json')});
if(!process.env.GITHUB_OUTPUT)throw Error('GITHUB_OUTPUT is required');
fs.appendFileSync(process.env.GITHUB_OUTPUT,`run_report=${decision.run}\nsend_line=${decision.send}\n`);
if(process.env.GITHUB_STEP_SUMMARY)fs.appendFileSync(process.env.GITHUB_STEP_SUMMARY,decision.reason+'\n\n');
console.log(decision.reason);
