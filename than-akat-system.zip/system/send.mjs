import fs from 'node:fs';import crypto from 'node:crypto';
import {reportSummary} from './summary.mjs';
import {writeDeliveryReceipt,readDeliveryReceipt,wasDelivered} from './delivery-state.mjs';
// Credentials are environment-only. Never place them in generated reports or logs.
const token=process.env.LINE_CHANNEL_ACCESS_TOKEN,to=process.env.LINE_USER_ID,base=process.env.REPORT_BASE_URL;
const delivery=JSON.parse(fs.readFileSync('public/delivery.json','utf8'));
const report=JSON.parse(fs.readFileSync('public/report.json','utf8'));
if(report.date!==new Intl.DateTimeFormat('en-CA',{timeZone:'Asia/Bangkok',year:'numeric',month:'2-digit',day:'2-digit'}).format(new Date()))throw Error('Refusing to send a report for a different date');
if(report.publication?.preview&&process.env.GITHUB_EVENT_NAME==='schedule'){console.log('Scheduled LINE starts with the first real issue; pre-launch preview skipped.');process.exit(0);}
if(!token||!to||!base)throw Error('Set LINE_CHANNEL_ACCESS_TOKEN, LINE_USER_ID and REPORT_BASE_URL as deployment secrets/config.');
if(!base.startsWith('https://'))throw Error('Image hosting must use HTTPS');
const join=p=>base.replace(/\/$/,'')+'/'+p;
const imageUrl=join(delivery.image),previewUrl=join(delivery.preview);
const targets=[{role:'personal',to}];
if(process.env.LINE_GROUP_ID){if(!/^C[0-9a-f]{32}$/i.test(process.env.LINE_GROUP_ID))throw Error('Invalid LINE_GROUP_ID');targets.push({role:'workgroup',to:process.env.LINE_GROUP_ID});}
const pending=targets.filter(t=>!wasDelivered(readDeliveryReceipt('public/line-delivery-state.json'),delivery.date,t.role));
if(!pending.length){console.log('All configured destinations already accepted today.');process.exit(0);}
let imageReady=false;for(let i=0;i<12;i++){try{const r=await fetch(imageUrl,{method:'HEAD',signal:AbortSignal.timeout(15000)});if(r.ok&&r.headers.get('content-type')?.includes('image/')){imageReady=true;break}}catch{}await new Promise(r=>setTimeout(r,5000))}
if(!imageReady)throw Error('Public report image not available; LINE send skipped');
const text=reportSummary(report);
for(const target of pending){
 if(target.role==='workgroup'){
  const response=await fetch('https://api.line.me/v2/bot/group/'+target.to+'/summary',{headers:{Authorization:'Bearer '+token},signal:AbortSignal.timeout(15000)});
  if(!response.ok)throw Error('Cannot verify target workgroup: HTTP '+response.status);
  const group=await response.json();if(group.groupName?.trim()!=='พว.')throw Error('Workgroup name does not match approved destination');
 }
 const hash=crypto.createHash('sha256').update('than-akat-daily-cutoff0700-v4-'+delivery.date+(target.role==='personal'?'':':workgroup')).digest('hex');
 const retryKey=`${hash.slice(0,8)}-${hash.slice(8,12)}-4${hash.slice(13,16)}-a${hash.slice(17,20)}-${hash.slice(20,32)}`;
 const body=JSON.stringify({to:target.to,messages:[{type:'text',text},{type:'image',originalContentUrl:imageUrl,previewImageUrl:previewUrl}]});
 for(let i=0;i<3;i++){
  let r;try{r=await fetch('https://api.line.me/v2/bot/message/push',{method:'POST',headers:{Authorization:'Bearer '+token,'Content-Type':'application/json','X-Line-Retry-Key':retryKey},body,signal:AbortSignal.timeout(25000)})}catch{if(i===2)throw Error('LINE connection failed for '+target.role);continue}
  if(r.ok||(r.status===409&&r.headers.get('x-line-accepted-request-id'))){writeDeliveryReceipt('public/line-delivery-state.json',delivery.date,new Date(),target.role);console.log('LINE accepted destination: '+target.role);break}
  if(r.status<500||i===2)throw Error('LINE rejected '+target.role+': HTTP '+r.status);
  await new Promise(r=>setTimeout(r,2000));
 }
}
