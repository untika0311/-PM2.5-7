import test from 'node:test';import assert from 'node:assert/strict';
import {reportSummary} from './summary.mjs';
test('LINE summary uses source timestamp, readable sections, no issue or missing-PHEOC note',()=>{
 const report={date:'2026-10-30',publication:{label:'1/2570'},air:{stamp:'2026-10-30 14:00:00',mean:15.3,above:0,provinces:[{name:'ขอนแก่น',value:17.3,highDays:0,past:[{max:null}]}]},rooms:{total:{rooms:221,districts:53,subdistricts:78},sourceDate:'2026-10-30'}};
 const text=reportSummary(report);
 assert.ok(text.includes('ข้อมูลฝุ่น วันที่ 30 ต.ค. 2569 เวลา 14.00 น.'));
 for(const absent of ['ฉบับที่','ข้อมูลย้อนหลังสำหรับคัดกรอง','https://','ทะเบียน','ประเมินตนเองผ่าน'])assert.ok(!text.includes(absent));
 assert.ok(text.includes('📍 ขอนแก่น 17.3 มคก./ลบ.ม. (ดี)'));assert.ok(text.includes('🏡'));assert.ok(text.includes('221 ห้อง'));assert.ok(text.includes('PM2.5 เฉลี่ยเขตสุขภาพที่ 7 15.3 มคก./ลบ.ม. (ดี)'));
 report.air.provinces[0].highDays=2;assert.ok(reportSummary(report).includes('ยังไม่ใช่การยืนยันเปิดจริง'));
});
