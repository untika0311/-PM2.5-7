import fs from 'node:fs';
import path from 'node:path';
import {airReport} from './core.mjs';

const [cache, date] = process.argv.slice(2);
const read = name => JSON.parse(fs.readFileSync(path.join(cache, name), 'utf8').replace(/^\uFEFF/, ''));
const {availableStations, totalStations} = airReport(read('latest.json'), read('history.json'), date);
console.log(JSON.stringify({availableStations, totalStations}));
