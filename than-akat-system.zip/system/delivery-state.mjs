import fs from 'node:fs';
import path from 'node:path';
export const bangkokDate=(now=new Date())=>new Intl.DateTimeFormat('en-CA',{timeZone:'Asia/Bangkok',year:'numeric',month:'2-digit',day:'2-digit'}).format(now);
export function readDeliveryReceipt(file){
  if(!fs.existsSync(file))return null;
  const r=JSON.parse(fs.readFileSync(file,'utf8'));
  if(r?.schemaVersion!==1||!/^\d{4}-\d{2}-\d{2}$/.test(r.date)||!Number.isFinite(Date.parse(r.acceptedAt)))throw Error('Invalid LINE delivery receipt');
  return r;
}
export function deliveryDecision({date,event,sendLine=false,firstIssueDate,receipt}){
  if(event==='workflow_dispatch')return {run:true,send:sendLine,reason:'Manual run'};
  if(date<firstIssueDate)return {run:false,send:false,reason:'Before first issue'};
  if(receipt?.date===date)return {run:false,send:false,reason:'LINE already accepted today; automatic duplicate skipped'};
  return {run:true,send:true,reason:'No accepted LINE delivery today; automatic attempt needed'};
}
export function writeDeliveryReceipt(file,date,now=new Date()){
  if(!/^\d{4}-\d{2}-\d{2}$/.test(date))throw Error('Invalid delivery date');
  fs.mkdirSync(path.dirname(file),{recursive:true});
  fs.writeFileSync(file+'.tmp',JSON.stringify({schemaVersion:1,date,acceptedAt:now.toISOString()},null,2)+'\n');
  fs.renameSync(file+'.tmp',file);
}
