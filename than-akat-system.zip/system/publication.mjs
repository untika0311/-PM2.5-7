import fs from 'node:fs';
import path from 'node:path';

const fiscalYear=date=>Number(date.slice(0,4))+543+(Number(date.slice(5,7))>=10?1:0);
export function emptyLedger(){return {schemaVersion:1,issues:[]};}
function validateLedger(ledger){
  if(ledger?.schemaVersion!==1||!Array.isArray(ledger.issues))throw Error('Invalid publication ledger');
  const dates=new Set(),numbers=new Set();
  for(const item of ledger.issues){
    const key=item.year+'/'+item.number;
    if(!/^\d{4}-\d{2}-\d{2}$/.test(item.date)||!Number.isInteger(item.number)||item.number<1||item.year!==fiscalYear(item.date)||dates.has(item.date)||numbers.has(key))throw Error('Conflicting publication ledger entries');
    dates.add(item.date);numbers.add(key);
  }
}
export function readLedger(file){
  const ledger=fs.existsSync(file)?JSON.parse(fs.readFileSync(file,'utf8').replace(/^\uFEFF/,'')):emptyLedger();
  validateLedger(ledger);return ledger;
}
export function planPublication(date,ledger,{firstIssueDate}){
  validateLedger(ledger);
  if(!/^\d{4}-\d{2}-\d{2}$/.test(date)||!/^\d{4}-\d{2}-\d{2}$/.test(firstIssueDate))throw Error('Invalid publication date');
  if(date<firstIssueDate){const year=fiscalYear(firstIssueDate);return {date,number:1,year,label:'1/'+year,preview:true};}
  const existing=ledger.issues.find(x=>x.date===date);
  if(existing)return {...existing,label:existing.number+'/'+existing.year,preview:false};
  if(ledger.issues.some(x=>x.date>date))throw Error('Cannot issue a previously unnumbered report before an existing report date');
  const year=fiscalYear(date),number=1+Math.max(0,...ledger.issues.filter(x=>x.year===year).map(x=>x.number));
  return {date,number,year,label:number+'/'+year,preview:false};
}
export function recordPublication(publication,ledger){
  validateLedger(ledger);
  if(publication.preview)return ledger;
  const existing=ledger.issues.find(x=>x.date===publication.date);
  if(existing){
    if(existing.number!==publication.number||existing.year!==publication.year)throw Error('Report number changed after rendering; rebuild the report');
    return ledger;
  }
  const next={schemaVersion:1,issues:[...ledger.issues,{date:publication.date,number:publication.number,year:publication.year}]};
  validateLedger(next);return next;
}
export function savePublication(file,publication){
  const before=readLedger(file),after=recordPublication(publication,before);
  if(after===before)return;
  fs.mkdirSync(path.dirname(file),{recursive:true});
  fs.writeFileSync(file+'.tmp',JSON.stringify(after,null,2)+'\n');
  fs.renameSync(file+'.tmp',file);
}
